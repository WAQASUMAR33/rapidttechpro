'use client'
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';

const Autoplayslider = ({ companyNames }) => {
  const containerRef = useRef(null);

  useGSAP(() => {
    const container = containerRef.current;

    // Duplicate the items for seamless scrolling
    const totalWidth = container.scrollWidth / 2; // Half of the extended width

    // Create the GSAP infinite scrolling animation
    gsap.to(container, {
      x: -totalWidth, // Scroll leftward by half the total width
      duration: 20,
      ease: 'none',
      repeat: -1,
      modifiers: {
        x: gsap.utils.unitize(value => parseFloat(value) % totalWidth), // Loop back seamlessly
      },
    });
  });

  const extendedNames = [...companyNames, ...companyNames]; // Clone for looping effect
//-rotate-3
  return (
    <div className="relative bg-white overflow-hidden py-10 md:py-10 mt-8 "> 
      <div ref={containerRef} className="flex whitespace-nowrap">
        <ul className="flex list-none p-0">
          {extendedNames.map((name, index) => (
            <li key={index} className="inline-flex items-center mr-12 text-3xl md:text-5xl font-light text-gray-700">
              <div className="md:h-5 md:w-5 h-3 w-3 bg-gray-700 rounded-full mr-4 flex items-center justify-center">
              </div>
              {name}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Autoplayslider;
