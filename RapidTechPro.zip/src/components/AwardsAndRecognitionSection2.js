// components/AwardsAndRecognitions.js
'use client';
import React, { useRef, useState, useEffect } from 'react';
import { FaStar } from 'react-icons/fa';
import { gsap } from 'gsap';
import Link from 'next/link';

const AwardsAndRecognitionsSection = () => {
  const awardsData = [
    { company: 'Clutch', rating: 4.9, description: 'Acclaimed as a top-rated software development company 2024', icon: <FaStar />, image: '/business/clutch.png', link: 'https://www.google.com/' },
    { company: 'GoodFirms', rating: 4.9, description: 'Acknowledged among the top software consulting experts 2024', icon: <FaStar />, image: '/business/bbborg.png', link: 'https://www.google.com/' },
    { company: 'Clutch', rating: 4.9, description: 'Acclaimed as a top-rated software development company 2024', icon: <FaStar />, image: '/business/trustpilot2.PNG', link: 'https://www.google.com/' },
    { company: 'GoodFirms', rating: 4.9, description: 'Acknowledged among the top software consulting experts 2024', icon: <FaStar />, image: '/business/goodfirms.png', link: 'https://www.google.com/' },
  ];

  const containerRef = useRef(null);
  const animationRef = useRef(null); // Store the GSAP animation instance
  const [isPaused, setIsPaused] = useState(false);

  // useEffect(() => {
  //   const container = containerRef.current;
  //   const scrollWidth = container.scrollWidth;

  //   // GSAP infinite scrolling animation
  //   animationRef.current = gsap.to(container, {
  //     scrollLeft: scrollWidth / 2, // Scroll halfway and reset
  //     duration: 20,
  //     ease: 'none',
  //     repeat: -1, // Infinite loop
  //     modifiers: {
  //       scrollLeft: gsap.utils.unitize(value => parseFloat(value) % (scrollWidth / 2)), // Seamless loop
  //     },
  //   });

  //   return () => {
  //     if (animationRef.current) {
  //       animationRef.current.kill(); // Clean up animation on component unmount
  //     }
  //   };
  // }, []);

  const handleMouseEnter = () => {
    setIsPaused(true);
    if (animationRef.current) {
      animationRef.current.pause();
    }
  };

  const handleMouseLeave = () => {
    setIsPaused(false);
    if (animationRef.current) {
      animationRef.current.play();
    }
  };

  return (
    <section className="text-black relative ">
      {/* Awards Slider */}
      <div
        ref={containerRef}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6  h-full cursor-pointer relative"
      >
        {awardsData.map((award, index) => (
          <Link href={award.link} key={index} className='flex flex-col h-[300px] justify-between items-center border border-black text-gray-800 rounded-xl p-6 w-full md:max-w-64 text-left transform transition-transform duration-300 hover:scale-105 hover:shadow-lg shadow-md'> 
          
            <div className="flex justify-between items-center gap-2 mb-4 w-full">
              <div className="flex justify-center items-center h-16 w-32 p-2  bg-white rounded-xl ">
                <img src={award.image} className='object-contain '></img>
                {/* <h3 className="font-semibold text-2xl text-gray-100">{award.company}</h3> */}
              </div>
              <div className="flex items-center gap-1">
                <span className="text-yellow-400 text-2xl">{award.icon}</span>
                <span className="text-xl 0">{award.rating}</span>
              </div>
            </div>
            <div className=" text-sm leading-snug overflow-hidden h-[80px]">
              {award.description}
            </div>
         
          </Link>
        ))}
      </div>

      {/* Left gradient overlay */}
      {/* <div className="absolute left-0 top-0 h-full w-6 md:w-12 bg-gradient-to-r from-white to-transparent pointer-events-none"></div> */}

      {/* Right gradient overlay */}
      {/* <div className="absolute right-0 top-0 h-full w-6 md:w-12 bg-gradient-to-l from-white to-transparent pointer-events-none"></div> */}
    </section>
  );
};

export default AwardsAndRecognitionsSection;
