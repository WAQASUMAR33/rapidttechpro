'use client';
import { useEffect, useState, useRef } from 'react';
import AwardsAndRecognitionsSection from './AwardsAndRecognitionSection2';
import Link from 'next/link';
import { FaArrowRight } from 'react-icons/fa';

export default function OurJourney() {
    const [completedProjects, setCompletedProjects] = useState(0);
    const [talentedTeam, setTalentedTeam] = useState(0);
    const [satisfiedClients, setSatisfiedClients] = useState(0);
    const [isVisible, setIsVisible] = useState(false);

    const ref = useRef(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.disconnect();
                }
            },
            { threshold: 0.1 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => observer.disconnect();
    }, []);

    useEffect(() => {
        if (!isVisible) return;

        const startCounter = (start, end, duration, setState) => {
            let current = start;
            const increment = (end - start) / (duration / 100);
            const interval = setInterval(() => {
                current += increment;
                if (current >= end) {
                    clearInterval(interval);
                    current = end;
                }
                setState(Math.floor(current));
            }, 100);
        };

        const duration = 2000;

        startCounter(400, 599, duration, setCompletedProjects);
        startCounter(0, 20, duration, setTalentedTeam);
        startCounter(100, 200, duration, setSatisfiedClients);
    }, [isVisible]);

    const teamMembers = [
        { name: "Waqas Umar", position: "CEO", image: "/team/waqas.png",link:'https://www.linkedin.com/in/waqas-umar-5b0678196/'},
        { name: "Kashif", position: "Co-founder", image: "/team/kashif.jpg",link:'https://www.linkedin.com/in/kashif-rasheed-seo/'},
        { name: "Usama", position: "UI/UX Designer", image: "/team/usama.png"},
        { name: "Ali", position: "Developer", image: "/team/ali.png" },
    ];

    return (
        <>
            <div className="grid grid-cols-1 gap-5 md:gap-0 md:grid-cols-5 bg-white md:px-12 px-2 py-4">
                <div className="grid grid-cols-1 md:col-span-4 md:gap-0">
                    <div
                        ref={ref}
                        className="md:h-full bg-white h-full flex flex-col gap-6 justify-center items-start md:py-16 py-10"
                    >
                        <div className="text-left">
                            <h2 className="md:text-5xl text-3xl font-bold text-black mb-4">
                                Our Journey to Empowering Innovation and Growth
                            </h2>
                            <p className="text-sm text-justify md:text-2xl text-gray-700 max-w-5xl">
                                At RapidTechPro, we are more than a software development company—we’re a full-cycle partner dedicated to transforming ideas into impactful solutions. Through creative problem-solving and technical expertise, we build user-centric products that address real challenges, enabling businesses to grow and thrive in a competitive world.
                            </p>
                        </div>
                    </div>
                    <AwardsAndRecognitionsSection />
                </div>

                {/* Our Team Section */}
                <div className="flex flex-col items-center w-full md:w-full">
                    <div className="w-full">
                        <h1 className="mb-8 text-xl md:text-3xl font-[700] text-center"> </h1>
                    </div>
                    <div className="flex md:justify-center justify-between items-center mt-8 ">
                        <div className="flex flex-col items-center justify-center space-y-1 relative ">
                            {teamMembers.map((member, index) => (
                                <div key={index} className="relative flex items-center py-4 justify-center group w-48 md:w-64 ">
                                    {/* Team Member Image */}
                                    <div className="flex-shrink-0 transition-transform duration-500 ease-out md:translate-x-0 -translate-x-20 transform md:group-hover:-translate-x-[60px]">
                                        <img
                                            src={member.image}
                                            className="md:w-24 md:h-24 w-32 h-32 rounded-full border-2 border-gray-300"
                                            alt={`${member.name} - ${member.position}`}
                                        />
                                        {/* Connecting Curved Line */}
                                        {/* {index < teamMembers.length - 1 && (
                                            <svg
                                                className={`absolute left-1/2 transform -translate-x-1/2 top-full h-16  transition-opacity duration-300 ease-out ${
                                                    'group-hover:opacity-0'
                                                }`}
                                                viewBox="0 0 2 40"
                                                fill="none"
                                            >
                                                <path
                                                    d="M1,0 Q1,20 1,40"
                                                    stroke="gray"
                                                    strokeWidth="1"
                                                    fill="transparent"
                                                />
                                            </svg>
                                        )} */}
                                    </div>

                                    {/* Team Member Details - Slide in on hover */}
                                    <div className="absolute left-0 md:opacity-0 group-hover:opacity-100 transition-all duration-500 ease-out transform md:group-hover:translate-x-[100px] translate-x-20 md:translate-x-0 ml-4">
                                        <div className=" p-4 rounded-lg ">
                                            <h3 className="text-xl font-semibold">{member.name}</h3>
                                            <p className="text-gray-600">{member.position}</p>
                                            {member.link&&(<>
                                            <Link className='flex gap-2 items-center hover:text-bluish' href={member.link} >Linkedin <FaArrowRight/></Link>
                                            </>)}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
