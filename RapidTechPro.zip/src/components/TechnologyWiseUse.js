export default function TechnologyWiseUse(){
    return(
        <>
        <div className=" bg-white md:px-12 px-2 py-10 ">
            <h1 className="md:text-5xl text-3xl font-bold">
            Technologies & Expert Talent at Your Service
            </h1>
            <p className="max-w-5xl text-lg text-justify md:text-2xl mt-8">
            Tap into our team of over 350 specialized experts in web, mobile, and software development. With deep expertise in the latest technologies and frameworks, we’re ready to seamlessly scale your development teams and bring your vision to life.

            </p>
        </div>
        </>
    )
}