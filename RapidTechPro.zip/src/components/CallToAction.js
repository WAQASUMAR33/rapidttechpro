// components/CallToAction.js
'use client'
import { useDispatch } from "react-redux";
import { openPopup } from "@/store/popupSlice";
export default function CallToAction() {
  const dispatch = useDispatch();
    return (
      <div className="bg-white py-10 md:py-32 flex flex-col items-center text-center">
        <p className="text-gray-500 text-lg mb-2">Pull the Trigger!</p>
        <p className="text-4xl md:text-7xl font-bold text-gray-900 mb-8">
        Get Started on <br>
        </br> Your Journey Today!
        </p>
        <button  onClick={() => dispatch(openPopup())} className="px-6 py-3 bg-black text-white rounded-full text-xs md:text-lg font-medium hover:bg-white hover:text-black border hover:border-black transition duration-200">
          Book free Consultancy
        </button>
      </div>
    );
  }
  