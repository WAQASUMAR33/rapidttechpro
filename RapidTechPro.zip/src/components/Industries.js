import { FaCar, FaMoneyBillWave, FaBuilding, FaUtensils, FaGraduationCap, FaHospital } from 'react-icons/fa';
import { motion } from 'framer-motion'; // Import Framer Motion

export default function Industries() {
  const industries = [
    {
      name: 'Automotive',
      description: 'Improve your vehicle management and enhance customer satisfaction with custom solutions.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaCar className="text-2xl md:text-4xl" />
    },
    {
      name: 'Finance',
      description: 'Get scalable solutions that improve the efficiency and security of your financial services.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaMoneyBillWave className="text-2xl md:text-4xl" />
    },
    {
      name: 'Real Estate',
      description: 'Our real estate solutions streamline operations, simplifying property management and sales.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaBuilding className="text-2xl md:text-4xl" />
    },
    {
      name: 'Hospitality',
      description: 'Get user-friendly solutions that enhance guest experiences and boost customer satisfaction.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaUtensils className="text-2xl md:text-4xl" />
    },
    {
      name: 'Education',
      description: 'Revolutionize ed-tech with solutions that boost student engagement and simplify learning.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaGraduationCap className="text-2xl md:text-4xl" />
    },
    {
      name: 'Healthcare',
      description: 'Our solutions enhance healthcare by streamlining processes and improving patient care.',
      tags: ['Fleet Management', 'Telematics', 'Dealer Portal', 'Inventory', 'CRM'],
      icon: <FaHospital className="text-2xl md:text-4xl" />
    },
  ];

  return (
    <div className="bg-white py-8 md:py-16 px-4 md:px-8">
      <div className="max-w-7xl mx-auto text-left mb-12">
        <h3 className="text-3xl md:text-[60px] font-[700] text-gray-900">
        Industries We Serve
        </h3>
        <p className="text-gray-600 mt-4 text-lg text-justify md:text-2xl max-w-4xl">
        With deep expertise across diverse sectors, we’re equipped to understand your unique challenges. Our tailored solutions are designed to tackle these obstacles head-on, delivering impactful results that drive growth and success.
        </p>
      </div>

      <div className="grid md:gap-x-9 md:gap-y-9 gap-x-2 gap-y-6 grid-cols-2 lg:grid-cols-3 md:max-w-7xl mx-auto">
        {industries.map((industry, index) => (
          <motion.div
            key={index}
            className="group border-2 flex flex-col justify-between rounded-xl p-2 md:p-6 md:h-[320px] pr-10 bg-white shadow-sm border-gray-500 hover:border-bluish relative text-black hover:text-bluish"
            initial={{ opacity: 0, y: 80 }} // Initial state off-screen
            whileInView={{ opacity: 1, y: 0 }} // Animate when in view
            viewport={{ once: true, amount: 0.3 }} // Trigger the animation when the card is in the viewport
            transition={{
              delay: index * 0.1, // Stagger delay for each card
              type: 'spring', // Spring animation for smoothness
              stiffness: 60, // Lower stiffness for smoother easing
              damping: 20, // Higher damping for a less bouncy animation
              duration: 1.2, // Increased duration for slower animation
              ease: 'easeInOut', // Smoother easing function
            }}
          >
            {/* Icon placed at the top of the card */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-full border-2 border-black group-hover:border-bluish md:w-16 md:h-16 w-12 h-12 flex justify-center items-center">
              {industry.icon}
            </div>

            <div>
              <h3 className="text-xl md:text-[36px] font-[700] text-gray-800 mb-2 mt-4">
                {industry.name}
              </h3>
            </div>
            <div>
              <p className="text-gray-600 mb-4 text-sm md:text-[24px] font-[400]  md:text-xl">{industry.description}</p>
            </div>
            <div className="flex flex-wrap gap-1 md:gap-2">
              {industry.tags.map((tag, i) => (
                <span
                  key={i}
                  className="text-xs md:text-lg font-medium text-gray-600 bg-gray-100 px-3 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
