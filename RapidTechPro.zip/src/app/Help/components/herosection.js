export default function Herosection(){
    return(
        <>
        <div className="py-40  flex justify-center items-center bg-[url('/images/herosection.png')] bg-cover">
            <h1 className="text-3xl md:text-5xl capitalize text-white font-[600]">How can we help you?</h1>

        </div>
        </>
    )
}