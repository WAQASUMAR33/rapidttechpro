export default function WhatWeBelieveIn(){
    return(
        <>
        <div className="px-12 py-20">

<h1>
    What We Beleive In
</h1>
        </div>
        </>
    )
}