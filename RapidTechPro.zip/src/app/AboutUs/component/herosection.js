export default function HerosectionAboutus(){
    return(
        <>
        <div className=" flex flex-col text-white px-6 md:px-20 pt-24 pb-10 bg-black">
            <h1 className="text-3xl md:text-5xl max-w-xl font-bold">
                Brilliant Tech Minds, Together!
            </h1>
            <p className="text-xl max-w-xl mt-4">We are a team of visionary leaders and problem-solvers utilizing our agile processes to build solutions for lasting value.</p>
        <img src="/images/herosection.png" className="w-full h-full rounded-2xl mt-4"></img>
        </div>
        </>
    )
}