export default function DetailSection(){
    return(
        <>
        <div className="w-6xl mx-auto grid grid-cols-2">
            <div>
                
            </div>
        </div>
        </>
    )
}