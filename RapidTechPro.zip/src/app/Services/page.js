import UserLayout from "../UserLayout"
import MainServicePage from "./Mainpage"
export default function ServicePage(){
    return(
        <UserLayout>
        <MainServicePage/>
        </UserLayout>
    )
}