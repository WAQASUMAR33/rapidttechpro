'use client'
import React, { useRef } from "react";

import Header from "@/components/Header";
import Herosection from "@/components/Herosection";
import OurJourney from "@/components/OurJourney";
import Autoplayslider from "@/components/AutoPlayCarousel";
import AwardsAndRecognitions from "@/components/AwardsRecognition";
import TechnologyWiseUse from "@/components/TechnologyWiseUse";
import TabsSection from "@/components/Tabs";
import CreateSoftwareSection from "@/components/CreateSoftwaresection";
import SuccessStories from "@/components/OurSuccessStories";
// import OurProductDevelopmentProcess from "@/components/OurProductDevelopmentProcess";
import OurClientsLove from "@/components/OurClientsLove";
import Industries from "@/components/Industries";
import BlogSection from "@/components/BlogsSection";
import CallToAction from "@/components/CallToAction";
import Footer from "@/components/Footer";
import ChatWithWhatsapp from "@/components/Chatwithwhatsapp";
import OurProductDevelopmentProcess from "@/components/ProductDevelopmentSlider";
import HomePageHeader from "@/components/HomePageHeader";
import AutoImagePlayCarousel from "@/components/AutoImagePlayCarousel";
import TwoColumnSection from "@/components/NewProductDevlopmentSlider";
import FooterWithCallToAction from "@/components/FooterWithCallToAction";

export default function Home() {
  const successStoriesRef = useRef(null); // Create a ref for SuccessStories

  const companyNames = [
    "Android",
    "IOS",
    "UX Design",
    "Web Design",
    "Software Development",
  ];
  const images = [
    '/carousel/launcher.png',
    '/carousel/softwaretesting.png',
    '/carousel/launcher.png',
    '/carousel/softwaretesting.png',
  ];

  return (
    <>
      <div className="bg-white">
        <ChatWithWhatsapp />
        <HomePageHeader />
        <Herosection />
        <AutoImagePlayCarousel/>
        <OurJourney />
        <div className=" w-full overflow-hidden py-2">
        <Autoplayslider companyNames={companyNames} />
        </div>
        <TechnologyWiseUse />
        
        {/* Pass the ref to TabsSection */}
        <TabsSection successStoriesRef={successStoriesRef} />
        
        <CreateSoftwareSection />
        
        {/* Attach the ref to SuccessStories */}
        <SuccessStories ref={successStoriesRef} />
        
        {/* <OurProductDevelopmentProcess /> */}
        <TwoColumnSection/>
        <OurClientsLove />
        <Industries />
        {/* <BlogSection /> */}
        <CallToAction />
        <Footer />
        {/* <FooterWithCallToAction/> */}
      </div>
    </>
  );
}
